# TROUBLESHOOTING — TỰ TRA CỨU VÀ BÁO LỖI

## 1. Quy trình xử lý sự cố
1. Ghi lại lỗi nguyên văn, thời điểm và thao tác ngay trước khi lỗi xuất hiện.
2. Kiểm tra mạng, phiên bản ứng dụng, quyền truy cập và trạng thái dịch vụ.
3. Thử tải lại/khởi động lại an toàn; với lỗi giao diện web, thử Hard Reload.
4. Tra cứu bằng từ khóa kỹ thuật và tài liệu chính thức.
5. Đọc câu trả lời/Issue, đối chiếu phiên bản và môi trường.
6. Nếu chưa giải quyết, gửi Bug Report đủ thông tin.

## 2. Toán tử Google
| Toán tử | Công dụng | Ví dụ |
|---|---|---|
| `site:` | Giới hạn website/tên miền | `site:docs.github.com authentication` |
| `"..."` | Tìm cụm từ chính xác | `"Permission denied (publickey)"` |
| `-` | Loại từ không mong muốn | `node npm install error -python` |

### Cách tạo truy vấn tốt
- Bỏ câu văn dài, giữ thông báo lỗi nguyên văn.
- Thêm tên công nghệ và phiên bản.
- Tìm tài liệu chính thức trước.
- Ví dụ: `site:docs.npmjs.com ERESOLVE peer dependency`

Không áp dụng máy móc một truy vấn cho mọi lỗi; thay từ khóa theo thông báo thực tế.

## 3. Đọc StackOverflow
- Ưu tiên câu trả lời được đánh dấu **Accepted Answer**, nhưng vẫn kiểm tra có phù hợp phiên bản hiện tại không.
- Xem Upvote như tín hiệu tham khảo, không phải bảo đảm đúng.
- Đọc ngày đăng và bình luận mới.
- Kiểm tra phiên bản runtime, hệ điều hành và framework.
- Không chạy lệnh nguy hiểm chỉ vì một câu trả lời đề xuất.

## 4. Đọc GitHub Issues
- **Open:** vấn đề đang mở; có thể chưa được xử lý.
- **Closed:** đã đóng; cần đọc lý do đóng, có thể đã fix, duplicate hoặc không tái hiện.
- Tìm nhãn `bug`, `documentation`, `question`, `fixed` nếu có.
- Kiểm tra phiên bản bị ảnh hưởng, phiên bản đã sửa và workaround.
- Chỉ áp dụng workaround khi hiểu tác động và có thể hoàn tác.

## 5. Prompt AI theo 3 thành phần
Công thức: **Ngữ cảnh – Lỗi nguyên văn – Yêu cầu**.

### Mẫu Prompt
```text
NGỮ CẢNH:
Tôi đang dùng [hệ điều hành], [tên công cụ] phiên bản [version].
Tôi đang thực hiện [mô tả thao tác].

LỖI NGUYÊN VĂN:
[Dán thông báo lỗi đầy đủ, đã loại bỏ token/mật khẩu/thông tin riêng tư]

YÊU CẦU:
1. Giải thích lỗi bằng ngôn ngữ dễ hiểu.
2. Nêu 3 nguyên nhân có khả năng nhất.
3. Hướng dẫn kiểm tra từng bước, ưu tiên cách an toàn và dễ hoàn tác.
4. Cho biết lệnh nào có thể làm thay đổi/xóa dữ liệu.
5. Nếu thiếu thông tin, hãy hỏi lại thay vì đoán.
```

Không đưa API Key, mật khẩu, dữ liệu khách hàng hoặc mã nguồn bí mật vào công cụ AI chưa được công ty phê duyệt.

## 6. Bug Reporting Framework — 4 bước
1. **Context:** môi trường, phiên bản, tài khoản/role thử nghiệm (không ghi mật khẩu), thời điểm và các bước tái hiện.
2. **Expected:** kết quả mong đợi.
3. **Actual:** kết quả thực tế, thông báo lỗi nguyên văn.
4. **Log/Screenshot:** log, ảnh chụp hoặc video ngắn đã che dữ liệu nhạy cảm.

### Mẫu Bug Report
```text
TIÊU ĐỀ:
[Module] Mô tả ngắn lỗi

1. CONTEXT
- OS/Browser:
- App/Version:
- Environment:
- Thời điểm:
- Steps to reproduce:
  1.
  2.
  3.

2. EXPECTED
- Kết quả mong đợi:

3. ACTUAL
- Kết quả thực tế:
- Error message nguyên văn:

4. LOG / SCREENSHOT
- Log:
- Ảnh/video đính kèm:
- Đã che token, email cá nhân và dữ liệu nhạy cảm: Có/Không

ĐÃ THỬ:
- [Các bước đã kiểm tra]

MỨC ĐỘ ẢNH HƯỞNG:
- Blocker / High / Medium / Low
```

### Ví dụ báo lỗi
**Tiêu đề:** `[Login] Trang đăng nhập trả về lỗi 403 sau khi đăng nhập bằng tài khoản thử nghiệm`

- Context: Chrome phiên bản đang dùng, môi trường staging, xảy ra lúc 09:20; tái hiện bằng cách mở trang staging và đăng nhập tài khoản test.
- Expected: chuyển đến Dashboard.
- Actual: hiển thị HTTP 403 Forbidden.
- Log/Screenshot: đính kèm ảnh đã che email; Network cho thấy request đăng nhập trả 403; không đính kèm cookie/token.

## 7. Khi nào cần báo IT ngay?
- Nghi ngờ lộ mật khẩu, OTP, API Key hoặc dữ liệu nội bộ.
- Thiết bị có dấu hiệu nhiễm mã độc.
- Tài khoản có đăng nhập lạ.
- Mất quyền truy cập dữ liệu quan trọng hoặc có nguy cơ mất dữ liệu.
- Sự cố ảnh hưởng nhiều người hoặc hệ thống sản xuất.

## 8. Checklist
- [ ] Đã ghi lại lỗi nguyên văn.
- [ ] Đã kiểm tra phiên bản và môi trường.
- [ ] Đã thử Hard Reload với lỗi giao diện web.
- [ ] Đã tìm tài liệu chính thức bằng từ khóa phù hợp.
- [ ] Đã đối chiếu Accepted Answer/Issue với phiên bản hiện tại.
- [ ] Prompt AI có đủ Ngữ cảnh – Lỗi – Yêu cầu.
- [ ] Bug Report có Context – Expected – Actual – Log/Screenshot.
- [ ] Đã loại bỏ secrets và dữ liệu nhạy cảm khỏi nội dung gửi đi.
