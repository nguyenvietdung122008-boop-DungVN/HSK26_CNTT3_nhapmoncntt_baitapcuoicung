# BROWSER SETUP — HỒ SƠ TRÌNH DUYỆT CHUYÊN NGHIỆP

## 1. Mục tiêu
Tách biệt dữ liệu cá nhân và công việc, giảm nhầm tài khoản, quản lý dấu trang và hạn chế quyền của tiện ích mở rộng.

## 2. Tạo hai Browser Profile
Tạo tối thiểu hai hồ sơ trong trình duyệt Chromium/Chrome/Edge:

| Profile | Mục đích | Đăng nhập |
|---|---|---|
| Personal | Mạng xã hội, mua sắm, email cá nhân | Tài khoản cá nhân |
| TechNova_Work | Email công ty, Drive, GitHub, công cụ làm việc | Tài khoản công việc |

### Các bước tham khảo trên Chrome/Edge
1. Mở trình duyệt.
2. Chọn biểu tượng Profile ở góc trên.
3. Chọn Add profile / Thêm hồ sơ.
4. Đặt tên `TechNova_Work`, chọn màu/biểu tượng dễ phân biệt.
5. Đăng nhập bằng tài khoản công việc được cấp.
6. Giữ Profile cá nhân riêng, không đồng bộ chung mật khẩu/cookie giữa hai môi trường.
7. Ghim Profile công việc vào taskbar nếu cần.

**Data Isolation:** mỗi Profile có dữ liệu trình duyệt riêng như cookies, session, history và extension settings. Không coi Profile là ranh giới bảo mật tuyệt đối: người có quyền truy cập máy/OS vẫn có thể truy cập dữ liệu trên máy.

## 3. Bookmark Manager
Tạo đúng ba thư mục cấp cao:
- `01_Work_Dev`: GitHub, công cụ quản lý dự án, tài liệu kỹ thuật.
- `02_Onboarding_Docs`: README nội bộ, quy trình, tài liệu đào tạo.
- `03_Tools`: DevTools, validator, công cụ chuyển đổi được công ty cho phép.

Ví dụ cấu trúc:
```text
Bookmarks Bar/
├── 01_Work_Dev/
│   ├── GitHub
│   └── Project Board
├── 02_Onboarding_Docs/
│   ├── Employee Handbook
│   └── Onboarding Kit
└── 03_Tools/
    ├── Browser DevTools Docs
    └── Markdown Guide
```
Chỉ bookmark trang chính thức/đã xác minh. Không lưu link đăng nhập giả hoặc trang tải phần mềm không rõ nguồn.

## 4. Extension theo nhóm
| Nhóm | Công dụng | Nguyên tắc |
|---|---|---|
| Dev Suite | Công cụ hỗ trợ phát triển, định dạng/kiểm tra mã | Chỉ cài từ cửa hàng chính thức, được IT cho phép |
| Productivity Suite | Ghi chú, quản lý tab, hỗ trợ đọc | Tránh extension trùng chức năng |
| Security Suite | Hỗ trợ kiểm tra quyền riêng tư/bảo mật | Không cài nhiều tiện ích bảo mật không rõ nguồn |

### Quy tắc cài đặt
1. Kiểm tra nhà phát triển, đánh giá, số người dùng và lịch sử cập nhật.
2. Đọc quyền extension yêu cầu.
3. Đặt **Site access** ở `On click` nếu tiện ích không cần chạy thường trực.
4. Không cấp quyền đọc/thay đổi dữ liệu trên mọi website nếu không thực sự cần.
5. Gỡ extension không dùng; rà soát định kỳ.
6. Không cài extension được gửi qua file lạ hoặc link không xác minh.

## 5. Thực hành DevTools F12
### Mở DevTools
- Nhấn `F12` hoặc `Ctrl + Shift + I` trên Windows.
- Tab **Elements**: xem cấu trúc HTML và CSS; thay đổi tại đây chỉ là tạm thời trên trình duyệt.
- Tab **Console**: xem lỗi JavaScript và thông báo.
- Tab **Network**: xem request, status code, thời gian tải.
- Tab **Application** (Chrome) / Storage tương đương: xem Cookies, Local Storage và dữ liệu site.

### Cache và Cookies khác nhau thế nào?
- **Cache:** lưu tài nguyên như ảnh, CSS, JavaScript để tải nhanh hơn.
- **Cookies:** dữ liệu nhỏ do website lưu trong trình duyệt, thường dùng cho session, tùy chọn hoặc nhận diện.
- Xóa cache không giống đăng xuất. Xóa cookies có thể khiến bạn bị đăng xuất khỏi website.

### Hard Reload
1. Mở trang đang kiểm tra.
2. Mở DevTools.
3. Nhấn giữ nút Reload hoặc nhấp chuột phải vào nút Reload.
4. Chọn **Empty Cache and Hard Reload** nếu trình duyệt cung cấp tùy chọn này.
5. Kiểm tra lại trang và tab Console/Network.

Không kết luận website lỗi giao diện trước khi thử tải lại cứng, kiểm tra Console và xác nhận đúng phiên bản môi trường.

## 6. Checklist
- [ ] Có Profile Personal.
- [ ] Có Profile TechNova_Work.
- [ ] Đã đăng nhập đúng tài khoản trong từng Profile.
- [ ] Có đủ 3 thư mục Bookmark.
- [ ] Đã rà soát extension và nguồn cài đặt.
- [ ] Site Access đặt On click khi phù hợp.
- [ ] Biết mở Elements, Console, Network.
- [ ] Phân biệt Cache và Cookies.
- [ ] Biết Hard Reload trước khi báo lỗi giao diện.
