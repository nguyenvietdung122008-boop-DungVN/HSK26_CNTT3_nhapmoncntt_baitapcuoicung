# SECURITY — CHECKLIST AN TOÀN THÔNG TIN

## 1. Mục tiêu
Bảo vệ danh tính số, tài khoản, dữ liệu cá nhân và secrets của dự án.

## 2. Password Manager: Bitwarden
Bitwarden là một lựa chọn Password Manager; chỉ tải từ trang chính thức và tuân theo chính sách IT của công ty.

### Thiết lập
1. Cài ứng dụng/extension từ nguồn chính thức.
2. Tạo tài khoản theo hướng dẫn và thiết lập Master Password dài, duy nhất, khó đoán.
3. Bật 2FA cho tài khoản vault nếu có thể.
4. Dùng Password Generator tạo mật khẩu riêng cho từng tài khoản, khuyến nghị 16–32 ký tự theo chính sách dịch vụ.
5. Lưu thông tin đăng nhập trong vault; không lưu Master Password cùng nơi với dữ liệu đăng nhập.
6. Bật khóa ứng dụng tự động và bảo vệ thiết bị.
7. Không chia sẻ vault hoặc mật khẩu qua chat.

**Nguyên tắc:** 1 tài khoản – 1 mật khẩu. Không tái sử dụng mật khẩu giữa email, GitHub, mạng xã hội và dịch vụ khác.

## 3. 2FA/TOTP
2FA (xác thực hai yếu tố) bổ sung lớp bảo vệ ngoài mật khẩu. TOTP tạo mã dùng một lần theo thời gian từ ứng dụng Authenticator.

### Quy trình tổng quát
1. Vào Security/Two-factor authentication của dịch vụ.
2. Chọn Authenticator App/TOTP nếu được hỗ trợ.
3. Quét QR bằng ứng dụng xác thực.
4. Nhập mã hiện tại để xác nhận.
5. Tạo và lưu Backup Codes trong nơi lưu trữ an toàn được công ty cho phép.
6. Thử quy trình khôi phục theo hướng dẫn dịch vụ.
7. Không chụp/gửi QR bí mật hoặc mã OTP cho người khác.

Ưu tiên Passkey hoặc Security Key nếu tổ chức hỗ trợ; TOTP là lựa chọn tốt hơn SMS trong nhiều tình huống. SMS không nên là phương thức chính nếu có phương thức mạnh hơn.

### Tài khoản cần rà soát
- GitHub.
- Email công ty.
- Tài khoản quản trị hoặc dịch vụ chứa dữ liệu nội bộ.

## 4. Nhận diện rủi ro
### Phishing
Email/tin nhắn giả mạo nhằm dụ bấm link, đăng nhập hoặc cung cấp thông tin. Dấu hiệu:
- Tạo cảm giác khẩn cấp, đe dọa khóa tài khoản.
- Địa chỉ người gửi hoặc tên miền gần giống nhưng sai chính tả.
- Link hiển thị và URL thật không khớp.
- Yêu cầu mật khẩu, OTP, Backup Codes hoặc thông tin thanh toán.

### Typosquatting
Kẻ xấu đăng ký tên miền gần giống tên miền thật, ví dụ thay một ký tự hoặc thêm dấu gạch. Hãy tự gõ địa chỉ chính thức hoặc dùng bookmark đã xác minh.

### Mã độc Crack
Phần mềm bẻ khóa thường bị đóng gói mã độc, đánh cắp thông tin hoặc cài cửa hậu. Không tải/cài crack, keygen hoặc file thực thi từ nguồn không tin cậy.

## 5. Quy tắc 5 KHÔNG
1. **Không** dùng chung một mật khẩu cho nhiều tài khoản.
2. **Không** chia sẻ OTP, Backup Codes, Master Password hoặc API Key.
3. **Không** bấm link/tải file đáng ngờ; xác minh người gửi và tên miền.
4. **Không** cài phần mềm crack hoặc extension không rõ nguồn.
5. **Không** commit `.env`, token, private key hoặc dữ liệu nhạy cảm lên Git.

## 6. Bảo vệ Secrets bằng .env và .gitignore
Secrets gồm API Key, access token, mật khẩu database và thông tin xác thực. Không viết trực tiếp vào mã nguồn.

### Tệp `.env.example` (được phép commit)
```dotenv
# Mau bien moi truong - khong dien secret that vao file nay
APP_ENV=development
API_BASE_URL=https://api.example.com
API_KEY=replace-with-your-local-value
DATABASE_URL=replace-with-your-local-value
```

### Tệp `.gitignore`
```gitignore
# Secrets va bien moi truong
.env
.env.*
!.env.example

# Dependencies
node_modules/

# Build output
dist/
build/

# Logs
*.log
npm-debug.log*

# OS / editor
.DS_Store
Thumbs.db
.vscode/
```

### Tạo `.env` cục bộ
1. Copy `.env.example` thành `.env`.
2. Điền giá trị thử nghiệm hoặc secrets được cấp hợp lệ.
3. Không gửi `.env` cho người khác.
4. Không đưa `.env` vào Git.
5. Kiểm tra:
```bash
git status
git check-ignore -v .env
```
Lệnh `git check-ignore -v .env` nên chỉ ra quy tắc trong `.gitignore`.

**Nếu `.env` đã từng được commit:** chỉ thêm `.gitignore` là chưa đủ. Cần thu hồi/rotate secret ngay, sau đó gỡ file khỏi tracking và xử lý lịch sử Git theo hướng dẫn IT.

## 7. Xử lý khi nghi lộ thông tin
- Dừng chia sẻ hoặc sử dụng thông tin bị lộ.
- Báo IT/đầu mối bảo mật ngay.
- Đổi/thu hồi mật khẩu, token hoặc API Key bị ảnh hưởng.
- Đăng xuất phiên lạ và kiểm tra nhật ký đăng nhập.
- Giữ lại bằng chứng cần thiết theo hướng dẫn; không phát tán file độc hại.

## 8. Checklist bảo mật
- [ ] Password Manager được cài từ nguồn chính thức.
- [ ] Master Password mạnh, duy nhất.
- [ ] Mỗi tài khoản có mật khẩu riêng.
- [ ] 2FA được bật cho GitHub và email công ty nếu hỗ trợ.
- [ ] Backup Codes được cất an toàn.
- [ ] Biết nhận diện Phishing và Typosquatting.
- [ ] Không cài crack/keygen.
- [ ] `.env` nằm trong `.gitignore`.
- [ ] `.env.example` không chứa secret thật.
- [ ] Đã kiểm tra `git status` trước commit.
