# CLOUD WORKSPACE — KHÔNG GIAN CỘNG TÁC ĐÁM MÂY

## 1. Mục đích
Thiết lập cách lưu trữ và cộng tác nhất quán, tránh thất lạc dữ liệu, chia sẻ nhầm quyền hoặc tạo nhiều bản không kiểm soát.

## 2. Hybrid Workflow: Local và Cloud
- **Local:** file làm việc trên ổ cứng máy tính; thuận tiện thao tác và có thể dùng khi mạng chập chờn.
- **Cloud:** bản đồng bộ/lưu trữ trên dịch vụ được công ty phê duyệt; hỗ trợ truy cập và cộng tác.
- **Hybrid Workflow:** làm việc trong thư mục đồng bộ được cấu hình đúng, kết hợp kiểm tra trạng thái đồng bộ và quy tắc sao lưu.

### Quy trình đề xuất
1. IT hướng dẫn cài Google Drive for desktop hoặc giải pháp đồng bộ công ty phê duyệt.
2. Đăng nhập bằng tài khoản công việc, không dùng tài khoản cá nhân cho dữ liệu nội bộ.
3. Chọn chế độ đồng bộ phù hợp với dung lượng và chính sách thiết bị.
4. Đặt thư mục dự án trong vùng đồng bộ đã được phê duyệt.
5. Chờ biểu tượng đồng bộ hoàn tất trước khi tắt máy hoặc ngắt mạng.
6. Thử mở file từ giao diện web để xác nhận file đã lên Cloud.
7. Nếu có xung đột phiên bản, không tự ý xóa; báo người quản lý dữ liệu.

**Lưu ý:** Đồng bộ không đồng nghĩa với sao lưu độc lập. Xóa hoặc mã hóa nhầm ở Local có thể đồng bộ lên Cloud. Dữ liệu quan trọng cần có chính sách backup/version history riêng.

## 3. Cây thư mục chuẩn
```text
technova-onboarding-kit/
├── docs/
├── cloud-workspace/
├── browser-setup/
├── security/
└── troubleshooting/
```
Quy tắc đặt tên:
- Dùng `kebab-case`: chữ thường, nối từ bằng dấu gạch ngang.
- Không dấu tiếng Việt, không khoảng trắng.
- Tên mô tả nội dung, tránh `final-final-v2`.
- Với bản phát hành, dùng số phiên bản hoặc ngày theo chuẩn thống nhất, ví dụ `meeting-notes-2026-11-16.md`.

## 4. Ma trận phân quyền mẫu
| Đối tượng | Quyền Drive | Phạm vi | Kênh giao tiếp |
|---|---|---|---|
| Nhân viên mới | Editor trên thư mục cá nhân của mình | Chỉ thư mục cá nhân | `#onboarding` — hỏi Mentor |
| Đồng đội cùng dự án | Editor trên thư mục dự án chung | Thành viên dự án được duyệt | `#dev-ten-du-an` |
| Thực tập sinh phòng ban khác | Commenter | Tài liệu cần góp ý | Kênh chuyên môn phù hợp |
| Người nhận thông báo | Viewer | Tài liệu thông báo | `#thong-bao` |
| Đối tác/khách mời | Viewer, Restricted theo email | Chỉ file được phê duyệt | Kênh/đầu mối đối ngoại |

### Ý nghĩa quyền
- **Viewer:** chỉ xem, không sửa nội dung.
- **Commenter:** xem và thêm nhận xét/gợi ý; không sửa trực tiếp nội dung chính.
- **Editor:** chỉnh sửa nội dung và có thể ảnh hưởng lớn đến tài liệu.

### Quy tắc bắt buộc
1. Không đặt `Anyone with the link` cùng quyền `Editor`.
2. Ưu tiên `Restricted` và cấp quyền theo đúng email.
3. Cấp quyền tối thiểu cần thiết; hết nhu cầu thì thu hồi quyền.
4. Kiểm tra quyền của thư mục cha vì quyền có thể được kế thừa.
5. Không gửi tài liệu nội bộ ra ngoài nếu chưa được chủ sở hữu/phụ trách cho phép.
6. Trước khi chia sẻ, xác nhận đúng người nhận, đúng file, đúng quyền.

## 5. Quy trình chia sẻ an toàn
1. Mở file/thư mục → **Share**.
2. Nhập email công việc chính xác.
3. Chọn Viewer/Commenter/Editor theo ma trận.
4. Kiểm tra General access là Restricted, trừ trường hợp đã được phê duyệt rõ ràng.
5. Gửi lời nhắn ngắn nêu mục đích và thời hạn truy cập nếu cần.
6. Định kỳ rà soát danh sách người có quyền.

## 6. Channel, Topic và Thread
- `#onboarding`: câu hỏi riêng về quy trình nhập môn; tag Mentor khi cần.
- `#dev-ten-du-an`: thảo luận kỹ thuật theo dự án.
- `#thong-bao`: thông báo chính thức; thành viên đọc, hạn chế chat tự do nếu cấu hình cho phép.
- Dùng **Thread/Reply in thread** để phản hồi đúng chủ đề, tránh làm trôi nội dung.
- Tag đúng người chịu trách nhiệm; không dùng `@all`/`@channel` nếu không khẩn cấp và không được phép.
- Không gửi “No-Hello” kiểu chỉ nhắn “Chào anh/chị” rồi chờ. Hãy nêu luôn câu hỏi và bối cảnh.

### Mẫu tin nhắn tốt
> Chào anh/chị [Tên Mentor], em đang cấu hình Drive cho dự án [Tên dự án]. Em đã cấp Viewer cho nhóm review theo hướng dẫn, nhưng một thành viên cần góp ý trực tiếp. Trường hợp này nên đổi sang Commenter hay dùng tài liệu góp ý riêng ạ?

## 7. Tình huống và cách xử lý
| Tình huống | Xử lý |
|---|---|
| Người nhận không mở được file | Kiểm tra email đăng nhập, quyền file và quyền thư mục cha |
| File báo đang đồng bộ | Chờ hoàn tất, kiểm tra mạng và trạng thái ứng dụng |
| Có hai bản cùng tên | Không xóa vội; xác định bản chuẩn với chủ sở hữu |
| Chia sẻ nhầm Editor | Thu hồi/đổi quyền ngay, báo quản lý nếu dữ liệu nhạy cảm |
| Link bị lộ | Hạn chế quyền/thu hồi link, đánh giá phạm vi truy cập và báo IT |

## 8. Checklist
- [ ] Đang dùng tài khoản công việc.
- [ ] Thư mục đúng cấu trúc và tên chuẩn.
- [ ] Đã xác nhận đồng bộ hoàn tất.
- [ ] Chia sẻ Restricted theo email khi có thể.
- [ ] Không có Anyone with the link + Editor.
- [ ] Đã dùng Thread và tag đúng người.
