# TECHNOVA ONBOARDING KIT
**Bộ hồ sơ nhập môn số an toàn dành cho nhân viên mới**

> Phiên bản: 1.0.0  
> Đối tượng: Nhân viên mới, thực tập sinh IT, Mentor và bộ phận vận hành  
> Phạm vi: Quy trình và cấu hình mẫu cho Startup TechNova

## 1. Giới thiệu
TechNova Onboarding Kit là bộ hướng dẫn giúp nhân viên mới thiết lập không gian làm việc số an toàn, thống nhất và dễ phối hợp. Bộ kit bao gồm không gian cộng tác đám mây, trình duyệt đa Profile, bảo mật tài khoản và quy trình tự tra cứu – báo lỗi.

## 2. Mục tiêu
- Tổ chức dữ liệu theo mô hình Hybrid Workflow: làm việc trên Local và đồng bộ lên Cloud.
- Áp dụng Data Isolation để tách biệt dữ liệu cá nhân và công việc.
- Chia sẻ đúng quyền Viewer, Commenter, Editor.
- Bảo vệ tài khoản bằng Password Manager và 2FA.
- Không đưa API Key, mật khẩu hoặc token vào Git.
- Giúp nhân viên tự xử lý lỗi thường gặp và báo lỗi có đủ thông tin.

## 3. Cấu trúc repository
```text
Lop_MonHoc_MiniProject_TechNova/
├── docs/
│   ├── README.md
│   └── srs-onboarding-kit.docx
├── cloud-workspace/
│   └── phan-quyen-chia-se.md
├── browser-setup/
│   └── ho-so-trinh-duyet.md
├── security/
│   ├── checklist-bao-mat.md
│   ├── .env.example
│   └── .gitignore
├── troubleshooting/
│   └── mau-bao-cao-loi.md
└── .env                 # Tạo tại máy cá nhân; KHÔNG commit
```

## 4. Hướng dẫn sử dụng nhanh
1. Tải và giải nén bộ dự án.
2. Mở VS Code → **File → Open Folder** → chọn thư mục gốc.
3. Đọc tài liệu theo thứ tự: `cloud-workspace/`, `browser-setup/`, `security/`, `troubleshooting/`.
4. Hoàn thành các checklist trong từng tài liệu.
5. Tạo file `.env` cục bộ từ `.env.example` nếu dự án thực hành cần biến môi trường.
6. Kiểm tra `git status` trước khi commit để chắc chắn `.env` không xuất hiện.
7. Đưa repository lên GitHub theo hướng dẫn ở mục 8.

## 5. Checklist Onboarding
- [ ] Đã tạo thư mục làm việc Local và bật đồng bộ Cloud phù hợp.
- [ ] Đã kiểm tra quyền chia sẻ theo nguyên tắc tối thiểu cần thiết.
- [ ] Đã tạo Browser Profile Personal và TechNova_Work.
- [ ] Đã sắp xếp Bookmark theo 3 nhóm chuẩn.
- [ ] Đã rà soát Extension và quyền truy cập website.
- [ ] Đã cài Password Manager và tạo mật khẩu riêng cho từng tài khoản.
- [ ] Đã bật 2FA bằng ứng dụng xác thực cho các tài khoản được hỗ trợ.
- [ ] Đã lưu Backup Codes ở nơi an toàn, không chia sẻ.
- [ ] Đã hiểu cách nhận diện Phishing và Typosquatting.
- [ ] Đã kiểm tra `.env` nằm trong `.gitignore`.
- [ ] Đã thực hành tìm kiếm và tạo Bug Report có Context, Expected, Actual, Log/Screenshot.
- [ ] Đã biết kênh liên hệ Mentor/IT và quy tắc giao tiếp Thread.

## 6. Bảng thiết bị và tài khoản
| Hạng mục | Mục đích | Người quản lý | Lưu ý |
|---|---|---|---|
| Máy tính công việc | Thiết bị làm việc chính | IT | Bật khóa màn hình, cập nhật hệ điều hành |
| Email công ty | Danh tính công việc | IT/Admin | Bật 2FA, không dùng chung mật khẩu |
| Google Drive/Cloud | Lưu trữ và cộng tác | Chủ sở hữu thư mục | Chia sẻ đúng email và quyền |
| Lark/Slack | Trao đổi nhóm | Admin Workspace | Dùng Channel và Thread |
| GitHub | Quản lý mã nguồn | Tech Lead | Bật 2FA, không commit secrets |
| Bitwarden | Quản lý mật khẩu | Từng nhân viên | Bảo vệ bằng mật khẩu chủ mạnh và 2FA |

> Không ghi mật khẩu, mã OTP, Backup Codes hoặc API Key vào bảng này.

## 7. Quy ước vận hành
- Chỉ lưu dữ liệu công việc trong tài khoản và thư mục do công ty phê duyệt.
- Chia sẻ theo nguyên tắc **Least Privilege** (chỉ cấp quyền tối thiểu cần thiết).
- Không gửi secrets qua chat, email hoặc repository.
- Không cài phần mềm crack hoặc extension không rõ nguồn gốc.
- Khi gặp lỗi, tự tra cứu bước đầu; nếu cần hỗ trợ, gửi Bug Report đủ thông tin.

## 8. Đưa dự án lên GitHub (dành cho người mới)
### Bước 1 — Kiểm tra Git
Mở Terminal trong VS Code và chạy:
```bash
git --version
```
Nếu máy chưa có Git, cài Git từ trang chính thức `https://git-scm.com/`, sau đó mở lại VS Code.

### Bước 2 — Khởi tạo repository local
Đảm bảo Terminal đang ở thư mục gốc dự án:
```bash
git init
git status
```
Kiểm tra `.env` không xuất hiện trong danh sách file chuẩn bị commit.

### Bước 3 — Commit lần đầu
```bash
git add .
git status
git commit -m "Initial TechNova onboarding kit"
```
Nếu Git yêu cầu cấu hình danh tính:
```bash
git config --global user.name "Ten Cua Ban"
git config --global user.email "email-cua-ban@example.com"
```
Dùng email bạn muốn gắn với commit; không cần đưa thông tin cá nhân nhạy cảm vào tài liệu.

### Bước 4 — Tạo repository trên GitHub
1. Đăng nhập GitHub.
2. Chọn **New repository**.
3. Đặt tên repository theo yêu cầu lớp/môn học.
4. Chọn Public hoặc Private theo yêu cầu giảng viên/công ty.
5. Nếu đã có README trong dự án local, nên tạo repository trống trên GitHub (không tạo thêm README/license tại bước này).

### Bước 5 — Kết nối và push
Thay `URL_REPOSITORY_CUA_BAN` bằng URL GitHub thật:
```bash
git branch -M main
git remote add origin URL_REPOSITORY_CUA_BAN
git push -u origin main
```

## 9. Kiểm tra trước khi nộp
- [ ] Repository có đủ 5 thư mục theo đề.
- [ ] README hiển thị đúng trên GitHub.
- [ ] File DOCX mở được và có mục lục.
- [ ] Không có `.env`, mật khẩu, token, API Key hoặc Backup Codes trong Git.
- [ ] Không có link công khai cấp Editor.
- [ ] Tên repository đúng quy định lớp/môn học.

## 10. Tài liệu trong bộ kit
- `cloud-workspace/phan-quyen-chia-se.md`: Hybrid Workflow, cây thư mục, phân quyền và giao tiếp.
- `browser-setup/ho-so-trinh-duyet.md`: Profile, Bookmark, Extension và DevTools.
- `security/checklist-bao-mat.md`: Password Manager, 2FA, phishing và bảo vệ secrets.
- `troubleshooting/mau-bao-cao-loi.md`: Toán tử tìm kiếm, StackOverflow, GitHub Issues, Prompt AI và Bug Report.
- `docs/srs-onboarding-kit.docx`: Đặc tả yêu cầu phần mềm (SRS).
